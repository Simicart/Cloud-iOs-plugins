//
//  PayUPayment.m
//  PayU_iOS_SDK
//
//  Created by Suryakant Sharma on 08/12/14.
//  Copyright (c) 2014 PayU, India. All rights reserved.
//

#import "PayUPayment.h"

@implementation PayUPayment

@end
